self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1122b211202ef2afb3006399b4c7079a",
    "url": "/vk-mini-app/index.html"
  },
  {
    "revision": "5164c91d1674f449da30",
    "url": "/vk-mini-app/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "02d552450aa50c190cff",
    "url": "/vk-mini-app/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "5164c91d1674f449da30",
    "url": "/vk-mini-app/static/js/2.9739747f.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/vk-mini-app/static/js/2.9739747f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "02d552450aa50c190cff",
    "url": "/vk-mini-app/static/js/main.7e243dfd.chunk.js"
  },
  {
    "revision": "2b01e6b5aba5296d1aa0",
    "url": "/vk-mini-app/static/js/runtime-main.36939593.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/vk-mini-app/static/media/persik.4e1ec840.png"
  }
]);